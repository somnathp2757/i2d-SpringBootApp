# Spring boot docker demo

## Prerequisites
1. Maven 3.8.7
2. Java 17
3. Postman

## Steps

1. Build your java application using maven tool.
2. Run your application
3. Test your rest api application in Postman by importing the collection json file included in the code base.